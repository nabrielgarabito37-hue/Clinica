# -*- coding: utf-8 -*-
"""
Base de datos del Sistema de Clinica Rural.
Usa SQLite: un solo archivo, sin necesidad de instalar servidor de base de datos.
"""
import sqlite3
import os
from datetime import datetime

# El archivo de base de datos vive junto al programa.
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "clinica.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Crea todas las tablas si no existen. Seguro de correr multiples veces."""
    conn = get_connection()
    cur = conn.cursor()

    # ---------- USUARIOS (doctores, enfermeras, recepcion) ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre_completo TEXT NOT NULL,
            usuario TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            rol TEXT NOT NULL CHECK(rol IN ('doctor', 'enfermera', 'recepcion', 'admin')),
            especialidad TEXT,
            activo INTEGER NOT NULL DEFAULT 1,
            creado_en TEXT NOT NULL
        )
    """)

    # ---------- PACIENTES ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS pacientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expediente TEXT UNIQUE NOT NULL,
            nombre_completo TEXT NOT NULL,
            fecha_nacimiento TEXT,
            sexo TEXT CHECK(sexo IN ('M', 'F', 'Otro')),
            cedula_identidad TEXT,
            telefono TEXT,
            direccion TEXT,
            contacto_emergencia_nombre TEXT,
            contacto_emergencia_telefono TEXT,
            tipo_sangre TEXT,
            alergias TEXT,
            condiciones_cronicas TEXT,
            activo INTEGER NOT NULL DEFAULT 1,
            creado_en TEXT NOT NULL,
            actualizado_en TEXT NOT NULL
        )
    """)

    # ---------- CITAS / TURNOS ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS citas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paciente_id INTEGER NOT NULL,
            doctor_id INTEGER,
            fecha TEXT NOT NULL,
            hora TEXT NOT NULL,
            motivo TEXT,
            estado TEXT NOT NULL DEFAULT 'pendiente' CHECK(estado IN ('pendiente','confirmada','atendida','cancelada','no_asistio')),
            notas TEXT,
            creado_en TEXT NOT NULL,
            FOREIGN KEY (paciente_id) REFERENCES pacientes(id),
            FOREIGN KEY (doctor_id) REFERENCES usuarios(id)
        )
    """)

    # ---------- HISTORIAL MEDICO (consultas) ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS consultas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paciente_id INTEGER NOT NULL,
            doctor_id INTEGER NOT NULL,
            cita_id INTEGER,
            fecha TEXT NOT NULL,
            motivo_consulta TEXT,
            sintomas TEXT,
            presion_arterial TEXT,
            temperatura TEXT,
            frecuencia_cardiaca TEXT,
            peso_kg TEXT,
            altura_cm TEXT,
            diagnostico TEXT,
            tratamiento TEXT,
            observaciones TEXT,
            requiere_seguimiento INTEGER NOT NULL DEFAULT 0,
            creado_en TEXT NOT NULL,
            FOREIGN KEY (paciente_id) REFERENCES pacientes(id),
            FOREIGN KEY (doctor_id) REFERENCES usuarios(id),
            FOREIGN KEY (cita_id) REFERENCES citas(id)
        )
    """)

    # ---------- RECETAS (medicinas indicadas en una consulta) ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS recetas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            consulta_id INTEGER NOT NULL,
            medicamento_id INTEGER,
            nombre_medicamento TEXT NOT NULL,
            dosis TEXT,
            frecuencia TEXT,
            duracion TEXT,
            cantidad_entregada INTEGER DEFAULT 0,
            FOREIGN KEY (consulta_id) REFERENCES consultas(id),
            FOREIGN KEY (medicamento_id) REFERENCES medicamentos(id)
        )
    """)

    # ---------- INVENTARIO DE MEDICINAS ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS medicamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            presentacion TEXT,
            cantidad_disponible INTEGER NOT NULL DEFAULT 0,
            cantidad_minima INTEGER NOT NULL DEFAULT 10,
            fecha_vencimiento TEXT,
            lote TEXT,
            proveedor TEXT,
            actualizado_en TEXT NOT NULL
        )
    """)

    # ---------- MOVIMIENTOS DE INVENTARIO (auditoria de entradas/salidas) ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS movimientos_inventario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicamento_id INTEGER NOT NULL,
            tipo TEXT NOT NULL CHECK(tipo IN ('entrada','salida','ajuste')),
            cantidad INTEGER NOT NULL,
            motivo TEXT,
            usuario_id INTEGER,
            fecha TEXT NOT NULL,
            FOREIGN KEY (medicamento_id) REFERENCES medicamentos(id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    """)

    conn.commit()

    # Crear usuario admin por defecto si no existe ninguno
    cur.execute("SELECT COUNT(*) as c FROM usuarios")
    if cur.fetchone()["c"] == 0:
        from werkzeug.security import generate_password_hash
        cur.execute("""
            INSERT INTO usuarios (nombre_completo, usuario, password_hash, rol, creado_en)
            VALUES (?, ?, ?, ?, ?)
        """, ("Administrador", "admin", generate_password_hash("clinica2026"), "admin", datetime.now().isoformat()))
        conn.commit()

    conn.close()


def now_iso():
    return datetime.now().isoformat()


if __name__ == "__main__":
    init_db()
    print("Base de datos inicializada en:", DB_PATH)
