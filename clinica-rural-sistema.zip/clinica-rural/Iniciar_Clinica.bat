@echo off
title Sistema de Clinica Rural
color 0A
echo ============================================
echo   Sistema de Clinica Rural
echo   Iniciando servidor local...
echo ============================================
echo.

cd backend

REM Verificar si las dependencias estan instaladas, si no, instalarlas
python -c "import flask" 2>nul
if errorlevel 1 (
    echo Instalando componentes necesarios por primera vez...
    echo Esto puede tardar un par de minutos. Solo pasa la primera vez.
    pip install flask
    echo.
)

echo Abriendo el sistema en su navegador...
echo NO CIERRE ESTA VENTANA mientras usa el sistema.
echo Para apagar el sistema, simplemente cierre esta ventana.
echo.

start http://127.0.0.1:5000

python app.py

pause
