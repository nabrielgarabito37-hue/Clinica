// ============================================================
// Pagina: Inventario de medicinas
// ============================================================

async function renderInventario(container) {
  container.innerHTML = `
    <div class="page-header">
      <div>
        <h2>Inventario de medicinas</h2>
        <p class="subtitle">Existencias y movimientos de farmacia interna</p>
      </div>
      <button class="btn btn-primary" id="btn-nuevo-medicamento">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        Agregar medicamento
      </button>
    </div>
    <div class="toolbar" style="margin-bottom:18px;">
      <div class="search-bar" style="margin-bottom:0;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/></svg>
        <input type="text" id="buscar-medicamento" placeholder="Buscar medicamento...">
      </div>
      <label style="display:flex; align-items:center; gap:7px; font-size:13.5px; color:var(--color-ink-soft); cursor:pointer;">
        <input type="checkbox" id="filtro-stock-bajo">
        Mostrar solo stock bajo
      </label>
    </div>
    <div id="medicamentos-table-container" class="table-card">
      <div class="empty-state"><p>Cargando inventario...</p></div>
    </div>
  `;

  document.getElementById("btn-nuevo-medicamento").addEventListener("click", () => abrirModalMedicamento());

  let debounceTimer;
  document.getElementById("buscar-medicamento").addEventListener("input", () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(cargarInventario, 300);
  });
  document.getElementById("filtro-stock-bajo").addEventListener("change", cargarInventario);

  cargarInventario();
}

async function cargarInventario() {
  const el = document.getElementById("medicamentos-table-container");
  const query = document.getElementById("buscar-medicamento").value;
  const soloBajos = document.getElementById("filtro-stock-bajo").checked;

  try {
    let url = "/medicamentos?";
    const parts = [];
    if (query) parts.push("q=" + encodeURIComponent(query));
    if (soloBajos) parts.push("bajos=1");
    url += parts.join("&");

    const medicamentos = await API.get(url);
    if (medicamentos.length === 0) {
      el.innerHTML = `<div class="empty-state"><div class="icon">💊</div><p>No se encontraron medicamentos.</p></div>`;
      return;
    }
    el.innerHTML = `
      <table>
        <thead><tr><th>Medicamento</th><th>Presentación</th><th>Disponible</th><th>Mínimo</th><th>Vencimiento</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          ${medicamentos.map(m => {
            const bajo = m.cantidad_disponible <= m.cantidad_minima;
            const vencido = m.fecha_vencimiento && m.fecha_vencimiento < hoyISO();
            return `
            <tr data-id="${m.id}">
              <td><strong>${escapeHtml(m.nombre)}</strong>${m.lote ? `<div class="cell-mono">Lote: ${escapeHtml(m.lote)}</div>` : ""}</td>
              <td class="cell-muted">${escapeHtml(m.presentacion || "—")}</td>
              <td><strong>${m.cantidad_disponible}</strong></td>
              <td class="cell-muted">${m.cantidad_minima}</td>
              <td class="cell-muted" style="${vencido ? "color:var(--color-alert); font-weight:600;" : ""}">${m.fecha_vencimiento ? formatFecha(m.fecha_vencimiento) : "—"}</td>
              <td><span class="badge ${bajo ? "badge-stock-bajo" : "badge-stock-ok"}">${bajo ? "Stock bajo" : "Disponible"}</span></td>
              <td style="text-align:right; display:flex; gap:4px; justify-content:flex-end;">
                <button class="btn-ghost btn-sm btn-movimiento" data-id="${m.id}" data-nombre="${escapeHtml(m.nombre)}">Entrada/Salida</button>
                <button class="btn-ghost btn-sm btn-editar-med" data-id="${m.id}">Editar</button>
              </td>
            </tr>
          `}).join("")}
        </tbody>
      </table>
    `;

    el.querySelectorAll(".btn-movimiento").forEach(btn => {
      btn.addEventListener("click", () => abrirModalMovimiento(btn.dataset.id, btn.dataset.nombre));
    });
    el.querySelectorAll(".btn-editar-med").forEach(btn => {
      btn.addEventListener("click", () => {
        const med = medicamentos.find(m => m.id === parseInt(btn.dataset.id));
        abrirModalMedicamento(med);
      });
    });
  } catch (err) {
    el.innerHTML = `<div class="empty-state"><p>No se pudo cargar el inventario: ${escapeHtml(err.message)}</p></div>`;
  }
}

function abrirModalMedicamento(medicamento = null) {
  const esEdicion = medicamento !== null;
  const body = `
    <form id="form-medicamento">
      <div class="form-grid">
        <div class="form-field span-2">
          <label>Nombre del medicamento *</label>
          <input type="text" name="nombre" required value="${escapeHtml(medicamento?.nombre || "")}">
        </div>
        <div class="form-field">
          <label>Presentación</label>
          <input type="text" name="presentacion" placeholder="Tableta, jarabe, ampolla..." value="${escapeHtml(medicamento?.presentacion || "")}">
        </div>
        <div class="form-field">
          <label>Lote</label>
          <input type="text" name="lote" value="${escapeHtml(medicamento?.lote || "")}">
        </div>
        ${!esEdicion ? `
        <div class="form-field">
          <label>Cantidad inicial</label>
          <input type="number" name="cantidad_disponible" min="0" value="0">
        </div>
        ` : ""}
        <div class="form-field">
          <label>Cantidad mínima (alerta)</label>
          <input type="number" name="cantidad_minima" min="0" value="${medicamento?.cantidad_minima ?? 10}">
        </div>
        <div class="form-field">
          <label>Fecha de vencimiento</label>
          <input type="date" name="fecha_vencimiento" value="${medicamento?.fecha_vencimiento || ""}">
        </div>
        <div class="form-field">
          <label>Proveedor</label>
          <input type="text" name="proveedor" value="${escapeHtml(medicamento?.proveedor || "")}">
        </div>
      </div>
      ${!esEdicion ? `<p class="help-text">La cantidad mínima sirve para avisarte cuando hay que reabastecer.</p>` : ""}
    </form>
  `;
  const footer = `
    <button class="btn btn-secondary" id="modal-cancel">Cancelar</button>
    <button class="btn btn-primary" id="modal-save">${esEdicion ? "Guardar cambios" : "Agregar medicamento"}</button>
  `;
  openModal(esEdicion ? "Editar medicamento" : "Nuevo medicamento", body, footer);

  document.getElementById("modal-cancel").addEventListener("click", closeModal);
  document.getElementById("modal-save").addEventListener("click", async () => {
    const form = document.getElementById("form-medicamento");
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const data = Object.fromEntries(new FormData(form).entries());
    if (data.cantidad_disponible !== undefined) data.cantidad_disponible = parseInt(data.cantidad_disponible) || 0;
    data.cantidad_minima = parseInt(data.cantidad_minima) || 0;

    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando...";

    try {
      if (esEdicion) {
        await API.put("/medicamentos/" + medicamento.id, data);
        showToast("Medicamento actualizado", "success");
      } else {
        data.usuario_id = Session.user.id;
        await API.post("/medicamentos", data);
        showToast("Medicamento agregado al inventario", "success");
      }
      closeModal();
      cargarInventario();
    } catch (err) {
      showToast("Error: " + err.message, "error");
      saveBtn.disabled = false;
      saveBtn.textContent = esEdicion ? "Guardar cambios" : "Agregar medicamento";
    }
  });
}

function abrirModalMovimiento(medId, nombre) {
  const body = `
    <form id="form-movimiento">
      <div class="form-grid single">
        <div class="form-field">
          <label>Tipo de movimiento</label>
          <select name="tipo">
            <option value="entrada">Entrada (llegó pedido / donación)</option>
            <option value="salida">Salida (uso fuera de receta, pérdida, vencido)</option>
            <option value="ajuste">Ajuste manual (corregir cantidad exacta)</option>
          </select>
        </div>
        <div class="form-field">
          <label>Cantidad</label>
          <input type="number" name="cantidad" min="0" required>
        </div>
        <div class="form-field">
          <label>Motivo / nota</label>
          <input type="text" name="motivo" placeholder="Ej: Pedido mensual, producto vencido...">
        </div>
      </div>
    </form>
  `;
  const footer = `
    <button class="btn btn-secondary" id="modal-cancel">Cancelar</button>
    <button class="btn btn-primary" id="modal-save">Registrar movimiento</button>
  `;
  openModal(`Movimiento de inventario — ${escapeHtml(nombre)}`, body, footer);

  document.getElementById("modal-cancel").addEventListener("click", closeModal);
  document.getElementById("modal-save").addEventListener("click", async () => {
    const form = document.getElementById("form-movimiento");
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const data = Object.fromEntries(new FormData(form).entries());
    data.cantidad = parseInt(data.cantidad) || 0;
    data.usuario_id = Session.user.id;

    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando...";

    try {
      await API.post(`/medicamentos/${medId}/movimiento`, data);
      showToast("Movimiento registrado", "success");
      closeModal();
      cargarInventario();
    } catch (err) {
      showToast("Error: " + err.message, "error");
      saveBtn.disabled = false;
      saveBtn.textContent = "Registrar movimiento";
    }
  });
}
