// ============================================================
// Pagina: Usuarios (doctores, enfermeras, recepcion)
// ============================================================

async function renderUsuarios(container) {
  container.innerHTML = `
    <div class="page-header">
      <div>
        <h2>Usuarios del sistema</h2>
        <p class="subtitle">Personal con acceso a la clínica</p>
      </div>
      <button class="btn btn-primary" id="btn-nuevo-usuario">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        Nuevo usuario
      </button>
    </div>
    <div id="usuarios-table-container" class="table-card">
      <div class="empty-state"><p>Cargando usuarios...</p></div>
    </div>
  `;

  document.getElementById("btn-nuevo-usuario").addEventListener("click", () => abrirModalUsuario());
  cargarUsuarios();
}

const ROL_LABELS = { doctor: "Doctor/a", enfermera: "Enfermero/a", recepcion: "Recepción", admin: "Administrador" };

async function cargarUsuarios() {
  const el = document.getElementById("usuarios-table-container");
  try {
    const usuarios = await API.get("/usuarios");
    el.innerHTML = `
      <table>
        <thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Especialidad</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          ${usuarios.map(u => `
            <tr data-id="${u.id}">
              <td><strong>${escapeHtml(u.nombre_completo)}</strong></td>
              <td class="cell-mono">${escapeHtml(u.usuario)}</td>
              <td class="cell-muted">${ROL_LABELS[u.rol] || u.rol}</td>
              <td class="cell-muted">${escapeHtml(u.especialidad || "—")}</td>
              <td><span class="badge ${u.activo ? "badge-stock-ok" : "badge-cancelada"}">${u.activo ? "Activo" : "Inactivo"}</span></td>
              <td style="text-align:right;">
                <button class="btn-ghost btn-sm btn-editar-usuario" data-id="${u.id}">Editar</button>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
    el.querySelectorAll(".btn-editar-usuario").forEach(btn => {
      btn.addEventListener("click", () => {
        const usuario = usuarios.find(u => u.id === parseInt(btn.dataset.id));
        abrirModalUsuario(usuario);
      });
    });
  } catch (err) {
    el.innerHTML = `<div class="empty-state"><p>No se pudo cargar la lista: ${escapeHtml(err.message)}</p></div>`;
  }
}

function abrirModalUsuario(usuario = null) {
  const esEdicion = usuario !== null;
  const body = `
    <form id="form-usuario">
      <div class="form-grid">
        <div class="form-field span-2">
          <label>Nombre completo *</label>
          <input type="text" name="nombre_completo" required value="${escapeHtml(usuario?.nombre_completo || "")}">
        </div>
        ${!esEdicion ? `
        <div class="form-field">
          <label>Usuario (para iniciar sesión) *</label>
          <input type="text" name="usuario" required value="${escapeHtml(usuario?.usuario || "")}">
        </div>
        ` : ""}
        <div class="form-field">
          <label>Rol *</label>
          <select name="rol" required>
            <option value="doctor" ${usuario?.rol === "doctor" ? "selected" : ""}>Doctor/a</option>
            <option value="enfermera" ${usuario?.rol === "enfermera" ? "selected" : ""}>Enfermero/a</option>
            <option value="recepcion" ${usuario?.rol === "recepcion" ? "selected" : ""}>Recepción</option>
            <option value="admin" ${usuario?.rol === "admin" ? "selected" : ""}>Administrador</option>
          </select>
        </div>
        <div class="form-field">
          <label>Especialidad</label>
          <input type="text" name="especialidad" placeholder="Medicina general..." value="${escapeHtml(usuario?.especialidad || "")}">
        </div>
        <div class="form-field">
          <label>${esEdicion ? "Nueva contraseña (opcional)" : "Contraseña *"}</label>
          <input type="password" name="password" ${esEdicion ? "" : "required"} placeholder="${esEdicion ? "Dejar en blanco para no cambiar" : ""}">
        </div>
        ${esEdicion ? `
        <div class="form-field">
          <label>Estado</label>
          <select name="activo">
            <option value="1" ${usuario?.activo ? "selected" : ""}>Activo</option>
            <option value="0" ${!usuario?.activo ? "selected" : ""}>Inactivo</option>
          </select>
        </div>
        ` : ""}
      </div>
    </form>
  `;
  const footer = `
    <button class="btn btn-secondary" id="modal-cancel">Cancelar</button>
    <button class="btn btn-primary" id="modal-save">${esEdicion ? "Guardar cambios" : "Crear usuario"}</button>
  `;
  openModal(esEdicion ? "Editar usuario" : "Nuevo usuario", body, footer);

  document.getElementById("modal-cancel").addEventListener("click", closeModal);
  document.getElementById("modal-save").addEventListener("click", async () => {
    const form = document.getElementById("form-usuario");
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const data = Object.fromEntries(new FormData(form).entries());
    if (data.activo !== undefined) data.activo = parseInt(data.activo);

    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando...";

    try {
      if (esEdicion) {
        await API.put("/usuarios/" + usuario.id, data);
        showToast("Usuario actualizado", "success");
      } else {
        await API.post("/usuarios", data);
        showToast("Usuario creado correctamente", "success");
      }
      closeModal();
      cargarUsuarios();
    } catch (err) {
      showToast("Error: " + err.message, "error");
      saveBtn.disabled = false;
      saveBtn.textContent = esEdicion ? "Guardar cambios" : "Crear usuario";
    }
  });
}
