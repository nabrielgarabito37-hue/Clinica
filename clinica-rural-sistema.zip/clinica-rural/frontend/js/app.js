// ============================================================
// App principal: router simple entre paginas
// ============================================================

const PAGE_RENDERERS = {
  inicio: renderInicio,
  pacientes: renderPacientes,
  "paciente-detalle": renderPacienteDetalle,
  citas: renderCitas,
  inventario: renderInventario,
  usuarios: renderUsuarios,
};

let currentPage = null;

function navigateTo(page, params = {}) {
  currentPage = page;
  closeModal();

  // Actualizar resaltado del menu lateral (paciente-detalle resalta "pacientes")
  const navKey = page === "paciente-detalle" ? "pacientes" : page;
  document.querySelectorAll(".nav-item").forEach(item => {
    item.classList.toggle("active", item.dataset.page === navKey);
  });

  const container = document.getElementById("page-container");
  const renderer = PAGE_RENDERERS[page];
  if (!renderer) {
    container.innerHTML = `<div class="empty-state"><p>Página no encontrada.</p></div>`;
    return;
  }
  renderer(container, params);
}

function setupNavigation() {
  document.querySelectorAll(".nav-item").forEach(item => {
    item.addEventListener("click", () => navigateTo(item.dataset.page));
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setupLogin();
  setupNavigation();
});
