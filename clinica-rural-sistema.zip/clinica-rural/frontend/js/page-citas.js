// ============================================================
// Pagina: Citas / Turnos
// ============================================================

async function renderCitas(container) {
  container.innerHTML = `
    <div class="page-header">
      <div>
        <h2>Citas</h2>
        <p class="subtitle">Agenda de turnos de la clínica</p>
      </div>
      <button class="btn btn-primary" id="btn-nueva-cita">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        Nueva cita
      </button>
    </div>
    <div class="day-picker">
      <input type="date" id="filtro-fecha" value="${hoyISO()}">
      <button class="today-btn" id="btn-hoy">Hoy</button>
    </div>
    <div id="citas-table-container" class="table-card">
      <div class="empty-state"><p>Cargando citas...</p></div>
    </div>
  `;

  document.getElementById("btn-nueva-cita").addEventListener("click", () => abrirModalCita());
  document.getElementById("filtro-fecha").addEventListener("change", (e) => cargarCitas(e.target.value));
  document.getElementById("btn-hoy").addEventListener("click", () => {
    document.getElementById("filtro-fecha").value = hoyISO();
    cargarCitas(hoyISO());
  });

  cargarCitas(hoyISO());
}

async function cargarCitas(fecha) {
  const el = document.getElementById("citas-table-container");
  try {
    const citas = await API.get("/citas?fecha=" + fecha);
    if (citas.length === 0) {
      el.innerHTML = `<div class="empty-state"><div class="icon">🗓️</div><p>No hay citas programadas para esta fecha.</p></div>`;
      return;
    }
    el.innerHTML = `
      <table>
        <thead><tr><th>Hora</th><th>Paciente</th><th>Doctor</th><th>Motivo</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          ${citas.map(c => `
            <tr data-id="${c.id}">
              <td><strong>${c.hora}</strong></td>
              <td class="clickable" data-paciente-id="${c.paciente_id}">${escapeHtml(c.paciente_nombre)} <span class="cell-mono">(${escapeHtml(c.expediente)})</span></td>
              <td class="cell-muted">${escapeHtml(c.doctor_nombre || "—")}</td>
              <td class="cell-muted">${escapeHtml(c.motivo || "—")}</td>
              <td>
                <select class="estado-select" data-id="${c.id}">
                  ${["pendiente","confirmada","atendida","cancelada","no_asistio"].map(s =>
                    `<option value="${s}" ${c.estado === s ? "selected" : ""}>${s.replace("_"," ")}</option>`
                  ).join("")}
                </select>
              </td>
              <td style="text-align:right; display:flex; gap:4px; justify-content:flex-end;">
                <button class="btn-ghost btn-sm btn-editar-cita" data-id="${c.id}">Editar</button>
                <button class="btn-ghost btn-sm btn-danger btn-eliminar-cita" data-id="${c.id}">Eliminar</button>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;

    el.querySelectorAll("[data-paciente-id]").forEach(cell => {
      cell.style.cursor = "pointer";
      cell.addEventListener("click", () => navigateTo("paciente-detalle", { id: cell.dataset.pacienteId }));
    });

    el.querySelectorAll(".estado-select").forEach(select => {
      select.addEventListener("change", async () => {
        try {
          const cita = citas.find(c => c.id === parseInt(select.dataset.id));
          await API.put("/citas/" + select.dataset.id, { ...cita, estado: select.value });
          showToast("Estado actualizado", "success");
        } catch (err) {
          showToast("Error: " + err.message, "error");
        }
      });
    });

    el.querySelectorAll(".btn-editar-cita").forEach(btn => {
      btn.addEventListener("click", () => {
        const cita = citas.find(c => c.id === parseInt(btn.dataset.id));
        abrirModalCita(cita);
      });
    });

    el.querySelectorAll(".btn-eliminar-cita").forEach(btn => {
      btn.addEventListener("click", async () => {
        if (!confirm("¿Eliminar esta cita? Esta acción no se puede deshacer.")) return;
        try {
          await API.del("/citas/" + btn.dataset.id);
          showToast("Cita eliminada", "success");
          cargarCitas(document.getElementById("filtro-fecha").value);
        } catch (err) {
          showToast("Error: " + err.message, "error");
        }
      });
    });

  } catch (err) {
    el.innerHTML = `<div class="empty-state"><p>No se pudo cargar la agenda: ${escapeHtml(err.message)}</p></div>`;
  }
}

async function abrirModalCita(cita = null) {
  const esEdicion = cita !== null;
  let pacientes = [], doctores = [];
  try {
    [pacientes, doctores] = await Promise.all([
      API.get("/pacientes"),
      API.get("/usuarios")
    ]);
    doctores = doctores.filter(u => u.rol === "doctor" || u.rol === "enfermera");
  } catch (err) {
    showToast("No se pudo cargar la información: " + err.message, "error");
    return;
  }

  const body = `
    <form id="form-cita">
      <div class="form-grid">
        <div class="form-field span-2">
          <label>Paciente *</label>
          <select name="paciente_id" required>
            <option value="">Seleccionar paciente...</option>
            ${pacientes.map(p => `<option value="${p.id}" ${cita?.paciente_id === p.id ? "selected" : ""}>${escapeHtml(p.nombre_completo)} (${escapeHtml(p.expediente)})</option>`).join("")}
          </select>
        </div>
        <div class="form-field span-2">
          <label>Doctor / Enfermera</label>
          <select name="doctor_id">
            <option value="">Sin asignar</option>
            ${doctores.map(d => `<option value="${d.id}" ${cita?.doctor_id === d.id ? "selected" : ""}>${escapeHtml(d.nombre_completo)}</option>`).join("")}
          </select>
        </div>
        <div class="form-field">
          <label>Fecha *</label>
          <input type="date" name="fecha" required value="${cita?.fecha || hoyISO()}">
        </div>
        <div class="form-field">
          <label>Hora *</label>
          <input type="time" name="hora" required value="${cita?.hora || ""}">
        </div>
        <div class="form-field span-2">
          <label>Motivo</label>
          <input type="text" name="motivo" value="${escapeHtml(cita?.motivo || "")}">
        </div>
        <div class="form-field span-2">
          <label>Notas</label>
          <textarea name="notas" rows="2">${escapeHtml(cita?.notas || "")}</textarea>
        </div>
      </div>
    </form>
  `;
  const footer = `
    <button class="btn btn-secondary" id="modal-cancel">Cancelar</button>
    <button class="btn btn-primary" id="modal-save">${esEdicion ? "Guardar cambios" : "Crear cita"}</button>
  `;
  openModal(esEdicion ? "Editar cita" : "Nueva cita", body, footer);

  document.getElementById("modal-cancel").addEventListener("click", closeModal);
  document.getElementById("modal-save").addEventListener("click", async () => {
    const form = document.getElementById("form-cita");
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const data = Object.fromEntries(new FormData(form).entries());

    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando...";

    try {
      if (esEdicion) {
        await API.put("/citas/" + cita.id, { ...data, estado: cita.estado });
        showToast("Cita actualizada", "success");
      } else {
        await API.post("/citas", data);
        showToast("Cita creada correctamente", "success");
      }
      closeModal();
      cargarCitas(document.getElementById("filtro-fecha").value);
    } catch (err) {
      showToast("Error: " + err.message, "error");
      saveBtn.disabled = false;
      saveBtn.textContent = esEdicion ? "Guardar cambios" : "Crear cita";
    }
  });
}
