// ============================================================
// Utilidades compartidas
// ============================================================

function showToast(message, type = "default") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = "toast" + (type !== "default" ? " " + type : "");
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

function formatFecha(isoString) {
  if (!isoString) return "—";
  const fecha = isoString.includes("T") ? isoString.split("T")[0] : isoString;
  const [y, m, d] = fecha.split("-");
  if (!y || !m || !d) return isoString;
  const meses = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  return `${parseInt(d)} ${meses[parseInt(m) - 1]} ${y}`;
}

function formatFechaHora(isoString) {
  if (!isoString) return "—";
  const [fecha, hora] = isoString.split("T");
  if (!hora) return formatFecha(fecha);
  return `${formatFecha(fecha)}, ${hora.substring(0, 5)}`;
}

function hoyISO() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

function calcularEdad(fechaNacimiento) {
  if (!fechaNacimiento) return null;
  const nacimiento = new Date(fechaNacimiento);
  const hoy = new Date();
  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const mesActual = hoy.getMonth() - nacimiento.getMonth();
  if (mesActual < 0 || (mesActual === 0 && hoy.getDate() < nacimiento.getDate())) edad--;
  return edad;
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function initials(nombre) {
  if (!nombre) return "--";
  const parts = nombre.trim().split(" ").filter(Boolean);
  if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function badgeEstadoCita(estado) {
  const labels = {
    pendiente: "Pendiente",
    confirmada: "Confirmada",
    atendida: "Atendida",
    cancelada: "Cancelada",
    no_asistio: "No asistió"
  };
  return `<span class="badge badge-${estado}">${labels[estado] || estado}</span>`;
}

// ---------------- Modal genérico ----------------
function openModal(titleHtml, bodyHtml, footerHtml) {
  closeModal();
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.id = "active-modal-overlay";
  overlay.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>${titleHtml}</h3>
        <button class="btn-ghost" id="modal-close-x" aria-label="Cerrar">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="modal-body">${bodyHtml}</div>
      ${footerHtml ? `<div class="modal-footer">${footerHtml}</div>` : ""}
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closeModal(); });
  document.getElementById("modal-close-x").addEventListener("click", closeModal);
  document.addEventListener("keydown", escCloseHandler);
}

function escCloseHandler(e) {
  if (e.key === "Escape") closeModal();
}

function closeModal() {
  const existing = document.getElementById("active-modal-overlay");
  if (existing) existing.remove();
  document.removeEventListener("keydown", escCloseHandler);
}
