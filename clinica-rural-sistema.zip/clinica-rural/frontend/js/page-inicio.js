// ============================================================
// Pagina: Inicio (Dashboard)
// ============================================================

async function renderInicio(container) {
  container.innerHTML = `
    <div class="page-header">
      <div>
        <h2>Buen día, ${escapeHtml((Session.user.nombre_completo || "").split(" ")[0])}</h2>
        <p class="subtitle">Resumen de hoy, ${formatFecha(hoyISO())}</p>
      </div>
    </div>
    <div id="stat-grid" class="stat-grid">
      ${skeletonStats()}
    </div>
    <div class="toolbar" style="margin-bottom:14px;">
      <h3 style="font-family: var(--font-display); font-size: 17px;">Citas de hoy</h3>
      <button class="btn btn-secondary btn-sm" data-nav="citas">Ver agenda completa →</button>
    </div>
    <div id="citas-hoy-container" class="table-card">
      <div class="empty-state"><p>Cargando...</p></div>
    </div>
  `;

  container.querySelector("[data-nav=citas]").addEventListener("click", () => navigateTo("citas"));

  try {
    const stats = await API.get("/dashboard");
    document.getElementById("stat-grid").innerHTML = renderStatCards(stats);
  } catch (err) {
    showToast("No se pudo cargar el resumen: " + err.message, "error");
  }

  try {
    const citas = await API.get("/citas?fecha=" + hoyISO());
    renderCitasHoy(citas);
  } catch (err) {
    document.getElementById("citas-hoy-container").innerHTML = `<div class="empty-state"><p>No se pudo cargar la agenda.</p></div>`;
  }
}

function skeletonStats() {
  return Array(4).fill(`
    <div class="stat-card"><div class="stat-accent"></div>
      <div class="stat-label">—</div><div class="stat-value">···</div>
    </div>
  `).join("");
}

function renderStatCards(stats) {
  return `
    <div class="stat-card">
      <div class="stat-accent"></div>
      <div class="stat-label">Pacientes registrados</div>
      <div class="stat-value">${stats.total_pacientes}</div>
    </div>
    <div class="stat-card secondary">
      <div class="stat-accent"></div>
      <div class="stat-label">Citas hoy</div>
      <div class="stat-value">${stats.citas_hoy}</div>
    </div>
    <div class="stat-card secondary">
      <div class="stat-accent"></div>
      <div class="stat-label">Pendientes hoy</div>
      <div class="stat-value">${stats.citas_pendientes_hoy}</div>
    </div>
    <div class="stat-card ${stats.medicamentos_bajos > 0 ? "alert" : ""}">
      <div class="stat-accent"></div>
      <div class="stat-label">Medicinas con stock bajo</div>
      <div class="stat-value">${stats.medicamentos_bajos}</div>
    </div>
  `;
}

function renderCitasHoy(citas) {
  const el = document.getElementById("citas-hoy-container");
  if (citas.length === 0) {
    el.innerHTML = `<div class="empty-state"><div class="icon">📋</div><p>No hay citas programadas para hoy.</p></div>`;
    return;
  }
  el.innerHTML = `
    <table>
      <thead><tr><th>Hora</th><th>Paciente</th><th>Doctor</th><th>Motivo</th><th>Estado</th></tr></thead>
      <tbody>
        ${citas.map(c => `
          <tr class="clickable" data-paciente-id="${c.paciente_id}">
            <td><strong>${c.hora}</strong></td>
            <td>${escapeHtml(c.paciente_nombre)}</td>
            <td class="cell-muted">${escapeHtml(c.doctor_nombre || "—")}</td>
            <td class="cell-muted">${escapeHtml(c.motivo || "—")}</td>
            <td>${badgeEstadoCita(c.estado)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
  el.querySelectorAll("tr.clickable").forEach(row => {
    row.addEventListener("click", () => navigateTo("paciente-detalle", { id: row.dataset.pacienteId }));
  });
}
