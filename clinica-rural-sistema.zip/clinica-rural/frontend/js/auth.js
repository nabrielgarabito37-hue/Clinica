// ============================================================
// Autenticacion. La sesion vive en memoria (variable JS),
// se vuelve a pedir login si se cierra la pestaña/navegador.
// ============================================================

const Session = {
  user: null,
  isLoggedIn() { return this.user !== null; },
};

function setupLogin() {
  const form = document.getElementById("login-form");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const usuario = document.getElementById("login-usuario").value.trim();
    const password = document.getElementById("login-password").value;
    const errorBox = document.getElementById("login-error-box");
    errorBox.innerHTML = "";

    const submitBtn = form.querySelector("button[type=submit]");
    submitBtn.disabled = true;
    submitBtn.textContent = "Ingresando...";

    try {
      const data = await API.post("/login", { usuario, password });
      Session.user = data.usuario;
      showAppShell();
    } catch (err) {
      errorBox.innerHTML = `<div class="login-error">${escapeHtml(err.message)}</div>`;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Ingresar";
    }
  });

  document.getElementById("logout-btn").addEventListener("click", () => {
    Session.user = null;
    document.getElementById("login-form").reset();
    document.getElementById("app-shell").style.display = "none";
    document.getElementById("login-screen").style.display = "flex";
  });
}

function showAppShell() {
  document.getElementById("login-screen").style.display = "none";
  document.getElementById("app-shell").style.display = "flex";

  document.getElementById("user-avatar").textContent = initials(Session.user.nombre_completo);
  document.getElementById("user-name").textContent = Session.user.nombre_completo;
  document.getElementById("user-role").textContent = Session.user.rol;

  navigateTo("inicio");
}
