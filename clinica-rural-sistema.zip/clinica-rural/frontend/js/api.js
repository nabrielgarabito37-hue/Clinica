// ============================================================
// Comunicacion con el backend local (mismo origen, sin internet)
// ============================================================

const API = {
  async _request(method, path, body) {
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res = await fetch("/api" + path, opts);
    let data;
    try {
      data = await res.json();
    } catch (e) {
      throw new Error("Respuesta inválida del servidor");
    }
    if (!res.ok) {
      throw new Error(data.error || "Ocurrió un error");
    }
    return data;
  },
  get(path) { return this._request("GET", path); },
  post(path, body) { return this._request("POST", path, body); },
  put(path, body) { return this._request("PUT", path, body); },
  del(path) { return this._request("DELETE", path); },
};
