// ============================================================
// Pagina: Pacientes (lista) y Detalle de Paciente (ficha)
// ============================================================

async function renderPacientes(container) {
  container.innerHTML = `
    <div class="page-header">
      <div>
        <h2>Pacientes</h2>
        <p class="subtitle">Expedientes registrados en la clínica</p>
      </div>
      <button class="btn btn-primary" id="btn-nuevo-paciente">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        Nuevo paciente
      </button>
    </div>
    <div class="search-bar">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/></svg>
      <input type="text" id="buscar-paciente" placeholder="Buscar por nombre, expediente o cédula...">
    </div>
    <div id="pacientes-table-container" class="table-card">
      <div class="empty-state"><p>Cargando pacientes...</p></div>
    </div>
  `;

  document.getElementById("btn-nuevo-paciente").addEventListener("click", () => abrirModalPaciente());

  let debounceTimer;
  document.getElementById("buscar-paciente").addEventListener("input", (e) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => cargarListaPacientes(e.target.value), 300);
  });

  cargarListaPacientes();
}

async function cargarListaPacientes(query = "") {
  const el = document.getElementById("pacientes-table-container");
  try {
    const pacientes = await API.get("/pacientes" + (query ? "?q=" + encodeURIComponent(query) : ""));
    if (pacientes.length === 0) {
      el.innerHTML = `<div class="empty-state"><div class="icon">🗂️</div><p>${query ? "No se encontraron pacientes con esa búsqueda." : "Aún no hay pacientes registrados. Agrega el primero."}</p></div>`;
      return;
    }
    el.innerHTML = `
      <table>
        <thead><tr><th>Expediente</th><th>Nombre</th><th>Edad</th><th>Sexo</th><th>Teléfono</th><th></th></tr></thead>
        <tbody>
          ${pacientes.map(p => `
            <tr class="clickable" data-id="${p.id}">
              <td class="cell-mono">${escapeHtml(p.expediente)}</td>
              <td><strong>${escapeHtml(p.nombre_completo)}</strong></td>
              <td class="cell-muted">${p.fecha_nacimiento ? calcularEdad(p.fecha_nacimiento) + " años" : "—"}</td>
              <td class="cell-muted">${p.sexo || "—"}</td>
              <td class="cell-muted">${escapeHtml(p.telefono || "—")}</td>
              <td style="text-align:right;">
                <button class="btn-ghost btn-sm" data-action="ver" data-id="${p.id}">Ver ficha →</button>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
    el.querySelectorAll("tr.clickable").forEach(row => {
      row.addEventListener("click", () => navigateTo("paciente-detalle", { id: row.dataset.id }));
    });
  } catch (err) {
    el.innerHTML = `<div class="empty-state"><p>No se pudo cargar la lista: ${escapeHtml(err.message)}</p></div>`;
  }
}

// ---------------- Modal: Crear / Editar paciente ----------------
function abrirModalPaciente(paciente = null) {
  const esEdicion = paciente !== null;
  const body = `
    <form id="form-paciente">
      <div class="form-section-title">Datos personales</div>
      <div class="form-grid">
        <div class="form-field span-2">
          <label>Nombre completo *</label>
          <input type="text" name="nombre_completo" required value="${escapeHtml(paciente?.nombre_completo || "")}">
        </div>
        <div class="form-field">
          <label>Fecha de nacimiento</label>
          <input type="date" name="fecha_nacimiento" value="${paciente?.fecha_nacimiento || ""}">
        </div>
        <div class="form-field">
          <label>Sexo</label>
          <select name="sexo">
            <option value="">Seleccionar...</option>
            <option value="M" ${paciente?.sexo === "M" ? "selected" : ""}>Masculino</option>
            <option value="F" ${paciente?.sexo === "F" ? "selected" : ""}>Femenino</option>
            <option value="Otro" ${paciente?.sexo === "Otro" ? "selected" : ""}>Otro</option>
          </select>
        </div>
        <div class="form-field">
          <label>Cédula de identidad</label>
          <input type="text" name="cedula_identidad" value="${escapeHtml(paciente?.cedula_identidad || "")}">
        </div>
        <div class="form-field">
          <label>Teléfono</label>
          <input type="text" name="telefono" value="${escapeHtml(paciente?.telefono || "")}">
        </div>
        <div class="form-field span-2">
          <label>Dirección</label>
          <input type="text" name="direccion" value="${escapeHtml(paciente?.direccion || "")}">
        </div>
      </div>

      <div class="form-section-title">Contacto de emergencia</div>
      <div class="form-grid">
        <div class="form-field">
          <label>Nombre</label>
          <input type="text" name="contacto_emergencia_nombre" value="${escapeHtml(paciente?.contacto_emergencia_nombre || "")}">
        </div>
        <div class="form-field">
          <label>Teléfono</label>
          <input type="text" name="contacto_emergencia_telefono" value="${escapeHtml(paciente?.contacto_emergencia_telefono || "")}">
        </div>
      </div>

      <div class="form-section-title">Información médica relevante</div>
      <div class="form-grid">
        <div class="form-field">
          <label>Tipo de sangre</label>
          <select name="tipo_sangre">
            <option value="">No registrado</option>
            ${["O+","O-","A+","A-","B+","B-","AB+","AB-"].map(t => `<option value="${t}" ${paciente?.tipo_sangre === t ? "selected" : ""}>${t}</option>`).join("")}
          </select>
        </div>
        <div class="form-field">
          <label>Condiciones crónicas</label>
          <input type="text" name="condiciones_cronicas" placeholder="Ej: Diabetes, hipertensión" value="${escapeHtml(paciente?.condiciones_cronicas || "")}">
        </div>
        <div class="form-field span-2">
          <label>Alergias</label>
          <input type="text" name="alergias" placeholder="Ej: Penicilina, polen" value="${escapeHtml(paciente?.alergias || "")}">
        </div>
      </div>
    </form>
  `;
  const footer = `
    <button class="btn btn-secondary" id="modal-cancel">Cancelar</button>
    <button class="btn btn-primary" id="modal-save">${esEdicion ? "Guardar cambios" : "Registrar paciente"}</button>
  `;
  openModal(esEdicion ? "Editar paciente" : "Nuevo paciente", body, footer);

  document.getElementById("modal-cancel").addEventListener("click", closeModal);
  document.getElementById("modal-save").addEventListener("click", async () => {
    const form = document.getElementById("form-paciente");
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const data = Object.fromEntries(new FormData(form).entries());

    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando...";

    try {
      if (esEdicion) {
        await API.put("/pacientes/" + paciente.id, data);
        showToast("Paciente actualizado correctamente", "success");
      } else {
        const res = await API.post("/pacientes", data);
        showToast(`Paciente registrado con expediente ${res.expediente}`, "success");
      }
      closeModal();
      if (esEdicion) {
        navigateTo("paciente-detalle", { id: paciente.id });
      } else {
        cargarListaPacientes();
      }
    } catch (err) {
      showToast("Error: " + err.message, "error");
      saveBtn.disabled = false;
      saveBtn.textContent = esEdicion ? "Guardar cambios" : "Registrar paciente";
    }
  });
}

// ============================================================
// FICHA DE DETALLE DEL PACIENTE (Historial medico)
// ============================================================

async function renderPacienteDetalle(container, params) {
  const pacienteId = params.id;
  container.innerHTML = `<div class="empty-state"><p>Cargando ficha del paciente...</p></div>`;

  let paciente;
  try {
    paciente = await API.get("/pacientes/" + pacienteId);
  } catch (err) {
    container.innerHTML = `<div class="empty-state"><p>No se pudo cargar el paciente: ${escapeHtml(err.message)}</p></div>`;
    return;
  }

  const edad = paciente.fecha_nacimiento ? calcularEdad(paciente.fecha_nacimiento) + " años" : "—";

  container.innerHTML = `
    <button class="btn-ghost btn-sm" id="btn-volver" style="margin-bottom:14px;">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
      Volver a pacientes
    </button>

    <div class="patient-header">
      <div>
        <span class="expediente-tag">${escapeHtml(paciente.expediente)}</span>
        <h2>${escapeHtml(paciente.nombre_completo)}</h2>
        <div class="patient-meta">
          <span><strong>${edad}</strong></span>
          <span>${paciente.sexo || "Sexo no registrado"}</span>
          <span>${escapeHtml(paciente.telefono || "Sin teléfono")}</span>
          <span>Sangre: <strong>${paciente.tipo_sangre || "No registrado"}</strong></span>
        </div>
        ${paciente.alergias ? `<div class="patient-meta"><span style="color:var(--color-alert);">⚠ Alergias: <strong>${escapeHtml(paciente.alergias)}</strong></span></div>` : ""}
      </div>
      <div style="display:flex; gap:8px; flex-shrink:0;">
        <button class="btn btn-secondary btn-sm" id="btn-editar-paciente">Editar datos</button>
        <button class="btn btn-primary btn-sm" id="btn-nueva-consulta">+ Nueva consulta</button>
      </div>
    </div>

    <div id="historial-container">
      <div class="empty-state"><p>Cargando historial médico...</p></div>
    </div>
  `;

  document.getElementById("btn-volver").addEventListener("click", () => navigateTo("pacientes"));
  document.getElementById("btn-editar-paciente").addEventListener("click", () => abrirModalPaciente(paciente));
  document.getElementById("btn-nueva-consulta").addEventListener("click", () => abrirModalConsulta(paciente));

  cargarHistorial(pacienteId);
}

async function cargarHistorial(pacienteId) {
  const el = document.getElementById("historial-container");
  try {
    const consultas = await API.get(`/pacientes/${pacienteId}/consultas`);
    if (consultas.length === 0) {
      el.innerHTML = `<div class="empty-state"><div class="icon">📋</div><p>Este paciente aún no tiene consultas registradas.</p></div>`;
      return;
    }
    el.innerHTML = `
      <h3 style="font-family: var(--font-display); font-size: 17px; margin-bottom: 14px;">Historial de consultas</h3>
      ${consultas.map(renderConsultaEntry).join("")}
    `;
  } catch (err) {
    el.innerHTML = `<div class="empty-state"><p>No se pudo cargar el historial: ${escapeHtml(err.message)}</p></div>`;
  }
}

function renderConsultaEntry(c) {
  const vitales = [
    { label: "Presión", value: c.presion_arterial },
    { label: "Temperatura", value: c.temperatura ? c.temperatura + "°C" : null },
    { label: "Frec. cardíaca", value: c.frecuencia_cardiaca ? c.frecuencia_cardiaca + " bpm" : null },
    { label: "Peso", value: c.peso_kg ? c.peso_kg + " kg" : null },
  ].filter(v => v.value);

  return `
    <div class="consult-entry">
      <div class="consult-entry-header">
        <span class="date">${formatFecha(c.fecha)}</span>
        <span class="doctor">Atendido por ${escapeHtml(c.doctor_nombre)}</span>
      </div>
      ${c.motivo_consulta ? `<div class="consult-row"><strong>Motivo:</strong>${escapeHtml(c.motivo_consulta)}</div>` : ""}
      ${c.sintomas ? `<div class="consult-row"><strong>Síntomas:</strong>${escapeHtml(c.sintomas)}</div>` : ""}
      ${vitales.length > 0 ? `
        <div class="consult-grid">
          ${vitales.map(v => `<div class="vital-item"><div class="label">${v.label}</div><div class="value">${escapeHtml(v.value)}</div></div>`).join("")}
        </div>
      ` : ""}
      ${c.diagnostico ? `<div class="consult-row"><strong>Diagnóstico:</strong>${escapeHtml(c.diagnostico)}</div>` : ""}
      ${c.tratamiento ? `<div class="consult-row"><strong>Tratamiento:</strong>${escapeHtml(c.tratamiento)}</div>` : ""}
      ${c.observaciones ? `<div class="consult-row"><strong>Observaciones:</strong>${escapeHtml(c.observaciones)}</div>` : ""}
      ${c.recetas && c.recetas.length > 0 ? `
        <div class="recipe-list">
          ${c.recetas.map(r => `
            <div class="recipe-pill">
              <span>💊</span>
              <span class="name">${escapeHtml(r.nombre_medicamento)}</span>
              <span class="cell-muted">${escapeHtml(r.dosis || "")} · ${escapeHtml(r.frecuencia || "")} · ${escapeHtml(r.duracion || "")}</span>
            </div>
          `).join("")}
        </div>
      ` : ""}
    </div>
  `;
}

// ---------------- Modal: Nueva consulta ----------------
async function abrirModalConsulta(paciente) {
  let doctores = [];
  let medicamentos = [];
  try {
    [doctores, medicamentos] = await Promise.all([
      API.get("/usuarios"),
      API.get("/medicamentos")
    ]);
    doctores = doctores.filter(u => u.rol === "doctor" || u.rol === "enfermera");
  } catch (err) {
    showToast("No se pudieron cargar doctores o medicamentos: " + err.message, "error");
    return;
  }

  const body = `
    <form id="form-consulta">
      <div class="form-grid">
        <div class="form-field">
          <label>Atendido por *</label>
          <select name="doctor_id" required>
            <option value="">Seleccionar...</option>
            ${doctores.map(d => `<option value="${d.id}" ${d.id === Session.user.id ? "selected" : ""}>${escapeHtml(d.nombre_completo)}</option>`).join("")}
          </select>
        </div>
        <div class="form-field">
          <label>Fecha *</label>
          <input type="date" name="fecha" required value="${hoyISO()}">
        </div>
        <div class="form-field span-2">
          <label>Motivo de consulta</label>
          <input type="text" name="motivo_consulta">
        </div>
        <div class="form-field span-2">
          <label>Síntomas</label>
          <textarea name="sintomas" rows="2"></textarea>
        </div>
      </div>

      <div class="form-section-title">Signos vitales</div>
      <div class="form-grid">
        <div class="form-field"><label>Presión arterial</label><input type="text" name="presion_arterial" placeholder="120/80"></div>
        <div class="form-field"><label>Temperatura (°C)</label><input type="text" name="temperatura" placeholder="37.0"></div>
        <div class="form-field"><label>Frec. cardíaca (bpm)</label><input type="text" name="frecuencia_cardiaca"></div>
        <div class="form-field"><label>Peso (kg)</label><input type="text" name="peso_kg"></div>
      </div>

      <div class="form-section-title">Diagnóstico y tratamiento</div>
      <div class="form-grid">
        <div class="form-field span-2"><label>Diagnóstico</label><textarea name="diagnostico" rows="2"></textarea></div>
        <div class="form-field span-2"><label>Tratamiento indicado</label><textarea name="tratamiento" rows="2"></textarea></div>
        <div class="form-field span-2"><label>Observaciones</label><textarea name="observaciones" rows="2"></textarea></div>
      </div>

      <div class="form-section-title">Recetas</div>
      <div id="recetas-list"></div>
      <button type="button" class="btn btn-secondary btn-sm" id="btn-add-receta" style="margin-top:6px;">+ Agregar medicamento</button>
    </form>
  `;
  const footer = `
    <button class="btn btn-secondary" id="modal-cancel">Cancelar</button>
    <button class="btn btn-primary" id="modal-save">Guardar consulta</button>
  `;
  openModal(`Nueva consulta — ${escapeHtml(paciente.nombre_completo)}`, body, footer);

  let recetaCount = 0;
  function agregarFilaReceta() {
    recetaCount++;
    const id = "receta-" + recetaCount;
    const row = document.createElement("div");
    row.className = "form-grid";
    row.style.marginBottom = "10px";
    row.dataset.recetaRow = id;
    row.innerHTML = `
      <div class="form-field span-2">
        <label>Medicamento</label>
        <select class="receta-medicamento">
          <option value="">Otro / no está en inventario...</option>
          ${medicamentos.map(m => `<option value="${m.id}" data-nombre="${escapeHtml(m.nombre)}" data-stock="${m.cantidad_disponible}">${escapeHtml(m.nombre)} (disp: ${m.cantidad_disponible})</option>`).join("")}
        </select>
        <input type="text" class="receta-nombre-manual" placeholder="Nombre del medicamento" style="margin-top:6px; display:none;">
      </div>
      <div class="form-field"><label>Dosis</label><input type="text" class="receta-dosis" placeholder="1 tableta"></div>
      <div class="form-field"><label>Frecuencia</label><input type="text" class="receta-frecuencia" placeholder="Cada 8 horas"></div>
      <div class="form-field"><label>Duración</label><input type="text" class="receta-duracion" placeholder="3 días"></div>
      <div class="form-field"><label>Cantidad a entregar</label><input type="number" class="receta-cantidad" min="0" value="0"></div>
      <div class="form-field" style="align-self:end;"><button type="button" class="btn-ghost btn-sm btn-danger remove-receta">Quitar</button></div>
    `;
    document.getElementById("recetas-list").appendChild(row);

    const select = row.querySelector(".receta-medicamento");
    const manualInput = row.querySelector(".receta-nombre-manual");
    select.addEventListener("change", () => {
      manualInput.style.display = select.value === "" ? "block" : "none";
    });
    row.querySelector(".remove-receta").addEventListener("click", () => row.remove());
  }

  document.getElementById("btn-add-receta").addEventListener("click", agregarFilaReceta);
  document.getElementById("modal-cancel").addEventListener("click", closeModal);

  document.getElementById("modal-save").addEventListener("click", async () => {
    const form = document.getElementById("form-consulta");
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const data = Object.fromEntries(new FormData(form).entries());
    data.paciente_id = paciente.id;

    const recetas = [];
    document.querySelectorAll("[data-receta-row]").forEach(row => {
      const select = row.querySelector(".receta-medicamento");
      const manual = row.querySelector(".receta-nombre-manual").value.trim();
      const nombre = select.value ? select.options[select.selectedIndex].dataset.nombre : manual;
      if (!nombre) return;
      recetas.push({
        medicamento_id: select.value ? parseInt(select.value) : null,
        nombre_medicamento: nombre,
        dosis: row.querySelector(".receta-dosis").value,
        frecuencia: row.querySelector(".receta-frecuencia").value,
        duracion: row.querySelector(".receta-duracion").value,
        cantidad_entregada: parseInt(row.querySelector(".receta-cantidad").value) || 0
      });
    });
    data.recetas = recetas;

    const saveBtn = document.getElementById("modal-save");
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando...";

    try {
      await API.post("/consultas", data);
      showToast("Consulta registrada correctamente", "success");
      closeModal();
      cargarHistorial(paciente.id);
    } catch (err) {
      showToast("Error: " + err.message, "error");
      saveBtn.disabled = false;
      saveBtn.textContent = "Guardar consulta";
    }
  });
}
